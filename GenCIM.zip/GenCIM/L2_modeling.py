import numpy as np
import matplotlib.pyplot as plt


# delay = np.array([151294.0, 32768.0, 151294.0, 556798.0, 621310.0])
# c_w = np.array([1.0, 0, 1.0, 4.0, 4.0])

def find_max_C_W(delay, c_w):
    vol_point_ = np.zeros((7,2)) 
    for i in range(7):
        vol_point_[i,0] = 0 if i == 0 else sum(delay[0:i])
        vol_point_[i,1] = sum(c_w[0:i+1])

    vload = sum(c_w)/sum(delay)

    delt = np.zeros(7)
    for i in range(7):
        delt[i] = vol_point_[i,1]/vload - vol_point_[i,0]

    t0 = max(delt)
    voL_L2_ = np.zeros((7,2))
    voL_L2_[:,0] = vol_point_[:,0]+t0
    voL_L2_[:,1] = vol_point_[:,1]-c_w

    L2_Demand = max(voL_L2_[:,0]*vload - voL_L2_[:,1])


    plt.scatter(vol_point_[:,0]+t0,vol_point_[:,1],marker='^')
    plt.scatter(voL_L2_[:,0],voL_L2_[:,1])
    x = np.array([0,2*1e6]);plt.plot(x,x*vload);plt.xlim(0);plt.ylim(0)
    
    print(sum(delay))
    plt.scatter(sum(delay), vol_point_[6,1])
    #vin = 25.6*1e-6

    plt.show()
    
    return L2_Demand


delay = np.array([151294.0, 151294.0, 151294.0, 32768.0, 151294.0, 556798.0, 621310.0])
c_w = np.array([1.0, 1.0, 1.0, 0, 1.0, 4.0, 4.0])

print(find_max_C_W(delay,c_w))




