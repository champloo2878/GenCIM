from evaluator import evaluate
import hw_config as cfg
import numpy as np
import matplotlib.pyplot as plt
import sw_decima as sd
import math as m

def lhd_max_length(acc0, ex_gli):
    max_length = 4
    tst_gli = (ex_gli[0],(max_length, ex_gli[1][1], ex_gli[1][2]))
    while evaluate(acc0, tst_gli, 'lhd') != {}:
        # print("lhd on", max_length, evaluate(acc0, tst_gli, 'lhd')['ee_L2'])
        max_length = max_length*2
        tst_gli = (ex_gli[0],(max_length, ex_gli[1][1], ex_gli[1][2]))
    return max_length

c = ['#F8E620', '#91D542', '#35B777', '#1F928B', '#30688D', '#413E85']

op_target = ['ee_L2', 'EDP', 'throughput']
#acc0 = cfg.hwc(config = cfg.Config(bus_width = 256, is_depth = 1024, al = 128, pc = 16, scr = 64, os_depth = 1024))
acc0 = cfg.hwc(config = cfg.Config(bus_width = 256, is_depth = 1024, al = 128, pc = 32, scr = 32, os_depth = 1024))

cmpme = np.zeros((3,4,6))
seq_len  = [128, 256, 512]

x = np.array([0,1,2])
plot_me = 0

for i in range(len(seq_len)):
    gli = ('a2a', (seq_len[i], 768, 12))

    # print(lhd_max_length(acc0, gli))

    metric_lhd = evaluate(acc0, gli, 'lhd')

    metric_2ph0, swdec0 = sd.block_decision(acc0, ('proj', (gli[1][0], gli[1][1]/gli[1][2], gli[1][0])), 'ee_L2')
    metric_2ph1, swdec1 = sd.block_decision(acc0, ('proj', (gli[1][1]/gli[1][2], gli[1][0], gli[1][0])), 'ee_L2')

    cmpme[i,0,0] = metric_lhd['energy'][18,0]
    cmpme[i,0,1] = metric_lhd['energy'][18,2]
    cmpme[i,0,2] = metric_lhd['energy'][18,4]
    cmpme[i,0,3] = metric_lhd['energy'][18,1]+metric_lhd['energy'][18,3]+metric_lhd['energy'][18,5]+metric_lhd['energy'][18,6]

    cmpme[i,0,4] = metric_lhd['energy_on_L2']
    #print('check:', metric_lhd['energy'][18,7] - cmpme[i,0,0] - cmpme[i,0,1] - cmpme[i,0,2] - cmpme[i,0,3])

    cmpme[i,1,0] = (metric_2ph0['energy'][18,0]+metric_2ph1['energy'][18,0])*gli[1][2]
    cmpme[i,1,1] = (metric_2ph0['energy'][18,2]+metric_2ph1['energy'][18,2])*gli[1][2]
    cmpme[i,1,2] = (metric_2ph0['energy'][18,4]+metric_2ph1['energy'][18,4])*gli[1][2]
    cmpme[i,1,3] = (metric_2ph0['energy'][18,1]+metric_2ph0['energy'][18,3]+metric_2ph0['energy'][18,5]+metric_2ph0['energy'][18,6]+metric_2ph1['energy'][18,1]+metric_2ph1['energy'][18,3]+metric_2ph1['energy'][18,5]+metric_2ph1['energy'][18,6])*gli[1][2]

    cmpme[i,1,4] = (metric_2ph0['energy_on_L2']+metric_2ph1['energy_on_L2'])*gli[1][2]
    #print('check:', (metric_2ph0['energy'][18,7]+metric_2ph1['energy'][18,7])*gli[1][2] - cmpme[i,1,0] - cmpme[i,1,1] - cmpme[i,1,2] - cmpme[i,1,3])

    plt.subplot(1,2,1)
    w=0.4
    ww=0.36
    plt.bar(x[i]-w/2, cmpme[i,1,4]+cmpme[i,1,0]+cmpme[i,1,1]+cmpme[i,1,2]+cmpme[i,1,3], width=ww, color=c[1])
    print((1-1/(cmpme[i,1,4]+cmpme[i,1,0]+cmpme[i,1,1]+cmpme[i,1,2]+cmpme[i,1,3])*(cmpme[i,0,4]+cmpme[i,0,0]+cmpme[i,0,1]+cmpme[i,0,2]+cmpme[i,0,3]))*100)
    plt.bar(x[i]-w/2, cmpme[i,1,4]+cmpme[i,1,0]+cmpme[i,1,1]+cmpme[i,1,2], width=ww, color=c[2])
    plt.bar(x[i]-w/2, cmpme[i,1,4]+cmpme[i,1,0]+cmpme[i,1,1], width=ww, color=c[3])
    plt.bar(x[i]-w/2, cmpme[i,1,4]+cmpme[i,1,0], width=ww, color=c[4])
    plt.bar(x[i]-w/2, cmpme[i,1,4], width=ww, color=c[5])

    plt.bar(x[i]+w/2, cmpme[i,0,4]+cmpme[i,0,0]+cmpme[i,0,1]+cmpme[i,0,2]+cmpme[i,0,3], width=ww, color=c[1])
    plt.bar(x[i]+w/2, cmpme[i,0,4]+cmpme[i,0,0]+cmpme[i,0,1]+cmpme[i,0,2], width=ww, color=c[2])
    plt.bar(x[i]+w/2, cmpme[i,0,4]+cmpme[i,0,0]+cmpme[i,0,1], width=ww, color=c[3])
    plt.bar(x[i]+w/2, cmpme[i,0,4]+cmpme[i,0,0], width=ww, color=c[4])
    plt.bar(x[i]+w/2, cmpme[i,0,4], width=ww, color=c[5])
    plt.xticks(x,labels=seq_len)

    metric_2ph0, swdec0 = sd.block_decision(acc0, ('proj', (gli[1][0], gli[1][1]/gli[1][2], gli[1][0])), 'throughput')
    metric_2ph1, swdec1 = sd.block_decision(acc0, ('proj', (gli[1][1]/gli[1][2], gli[1][0], gli[1][0])), 'throughput')

    cmpme[i,2,0] = sum(metric_lhd['icnt'][0:2])*2/1e6
    cmpme[i,2,1] = sum(metric_lhd['icnt'][2:4])*2/1e6
    cmpme[i,2,2] = sum(metric_lhd['icnt'][4:9])*2/1e6
    cmpme[i,2,3] = sum(metric_lhd['icnt'][9:15])*2/1e6
    cmpme[i,2,4] = metric_lhd['icnt'][15]*2/1e6
    cmpme[i,2,5] = metric_lhd['icnt'][16]*2/1e6
    #print('check:', sum(cmpme[i,2,:])-metric_lhd['delay']/1e6)

    cmpme[i,3,0] = gli[1][2]*sum(metric_2ph0['icnt'][0:2]+metric_2ph1['icnt'][0:2])*2/1e6
    cmpme[i,3,1] = gli[1][2]*sum(metric_2ph0['icnt'][2:4]+metric_2ph1['icnt'][2:4])*2/1e6
    cmpme[i,3,2] = gli[1][2]*sum(metric_2ph0['icnt'][4:9]+metric_2ph1['icnt'][4:9])*2/1e6
    cmpme[i,3,3] = gli[1][2]*sum(metric_2ph0['icnt'][9:15]+metric_2ph1['icnt'][9:15])*2/1e6
    cmpme[i,3,4] = gli[1][2]*(metric_2ph0['icnt'][15]+metric_2ph1['icnt'][15])*2/1e6
    cmpme[i,3,5] = gli[1][2]*(metric_2ph0['icnt'][16]+metric_2ph1['icnt'][16])*2/1e6
    #print('check:', sum(cmpme[i,3,:])-gli[1][2]*(metric_2ph0['delay']+metric_2ph1['delay'])/1e6)   

    plt.subplot(1,2,2)
    plt.bar(x[i]+w/2, cmpme[i,2,4]+cmpme[i,2,0]+cmpme[i,2,1]+cmpme[i,2,2]+cmpme[i,2,3]+cmpme[i,2,5], width=ww, color=c[0])
    print((1-(cmpme[i,2,4]+cmpme[i,2,0]+cmpme[i,2,1]+cmpme[i,2,2]+cmpme[i,2,3])/(cmpme[i,3,4]+cmpme[i,3,0]+cmpme[i,3,1]+cmpme[i,3,2]+cmpme[i,3,3]))*100)
    plt.bar(x[i]+w/2, cmpme[i,2,3]+cmpme[i,2,0]+cmpme[i,2,1]+cmpme[i,2,2]+cmpme[i,2,4], width=ww, color=c[1])
    plt.bar(x[i]+w/2, cmpme[i,2,2]+cmpme[i,2,0]+cmpme[i,2,1]+cmpme[i,2,3], width=ww, color=c[2])
    plt.bar(x[i]+w/2, cmpme[i,2,1]+cmpme[i,2,0]+cmpme[i,2,2], width=ww, color=c[3])
    plt.bar(x[i]+w/2, cmpme[i,3,1]+cmpme[i,3,0], width=ww, color=c[4])
    plt.bar(x[i]+w/2, cmpme[i,2,0], width=ww, color=c[5])

    plt.bar(x[i]-w/2, cmpme[i,3,4]+cmpme[i,3,0]+cmpme[i,3,1]+cmpme[i,3,2]+cmpme[i,3,3]+cmpme[i,3,5], width=ww, color=c[0])
    plt.bar(x[i]-w/2, cmpme[i,3,3]+cmpme[i,3,0]+cmpme[i,3,1]+cmpme[i,3,2]+cmpme[i,3,4], width=ww, color=c[1])
    plt.bar(x[i]-w/2, cmpme[i,3,2]+cmpme[i,3,0]+cmpme[i,3,1]+cmpme[i,3,3], width=ww, color=c[2])
    plt.bar(x[i]-w/2, cmpme[i,3,1]+cmpme[i,3,0]+cmpme[i,3,2], width=ww, color=c[3])
    plt.bar(x[i]-w/2, cmpme[i,3,1]+cmpme[i,3,0], width=ww, color=c[4])
    plt.bar(x[i]-w/2, cmpme[i,3,0], width=ww, color=c[5])

    plt.xticks(x,labels=seq_len)


print(swdec0,swdec1)
plt.show()














