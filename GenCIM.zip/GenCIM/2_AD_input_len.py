import numpy as np
import matplotlib.pyplot as plt

# input seq len
x = np.zeros(5)
x[0] = 1
x[1] = 128
x[2] = 256
x[3] = 384
x[4] = 512

x_plot = np.array([range(5)])

hidden_size = 512

ad = 1/(1/x + 1/hidden_size)

act_size = x*hidden_size

plt.scatter(x_plot,ad)
# plt.scatter(x_plot,act_size)

plt.show()




