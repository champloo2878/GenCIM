import numpy as np
from evaluator import evaluate
import hw_config as cfg
from sw_decima import block_decision


bus_width = 128
is_depth = 64
al = 256
pc = 32
scr = 64
os_depth = 128

acc0 = cfg.hwc(config = cfg.Config(bus_width = bus_width, is_depth = is_depth, al = al, pc = pc, scr = scr, os_depth = os_depth))

seq_len = 512
hidden_size = 1024
head_num = 16

op_target = 'ee_L2'

# energy breakdown
m0 = block_decision(acc0, ('proj',(seq_len, hidden_size, hidden_size)), op_target)

m1 = block_decision(acc0, ('a2a',(seq_len, hidden_size, head_num)), op_target)

# m2 = m0 # concat, m0 * 4

m3 = block_decision(acc0, ('proj',(seq_len, hidden_size, hidden_size*4)), op_target)

m4 = block_decision(acc0, ('proj',(seq_len, hidden_size*4, hidden_size)), op_target)

#m0*4 +m1 +m3 +m4
energy = np.zeros(5)
energy[0] = m0[0]['energy'][18,0]*4 + m1[0]['energy'][18,0] + m3[0]['energy'][18,0] + m4[0]['energy'][18,0] # IS

energy[1] = m0[0]['energy'][18,2]*4 + m1[0]['energy'][18,2] + m3[0]['energy'][18,2] + m4[0]['energy'][18,2] # CIM

energy[2] = m0[0]['energy'][18,4]*4 + m1[0]['energy'][18,4] + m3[0]['energy'][18,4] + m4[0]['energy'][18,4] # OS

energy[3] = m0[0]['energy'][18,1]*4 + m1[0]['energy'][18,1] + m3[0]['energy'][18,1] + m4[0]['energy'][18,1] + \
    m0[0]['energy'][18,3]*4 + m1[0]['energy'][18,3] + m3[0]['energy'][18,3] + m4[0]['energy'][18,3] + \
    m0[0]['energy'][18,5]*4 + m1[0]['energy'][18,5] + m3[0]['energy'][18,5] + m4[0]['energy'][18,5] + \
    m0[0]['energy'][18,6]*4 + m1[0]['energy'][18,6] + m3[0]['energy'][18,6] + m4[0]['energy'][18,6] # REGS

energy[4] = m0[0]['energy_on_L2']*4 + m1[0]['energy_on_L2'] + m3[0]['energy_on_L2'] + m4[0]['energy_on_L2'] # L2

total_energy = m0[0]['energy'][18,7]*4 + m1[0]['energy'][18,7] + m3[0]['energy'][18,7] + m4[0]['energy'][18,7] # OS
print('check:',total_energy-energy[0]-energy[1]-energy[2]-energy[3])

print(energy)

latency = np.zeros(6)
start,end = 0,2
latency[0] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6
start,end = 2,4
latency[1] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6
start,end = 4,9
latency[2] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6
start,end = 9,15
latency[3] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6
start,end = 15,15
latency[4] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6
start,end = 16,16
latency[5] = sum(m0[0]['icnt'][start:end])*2/1e6*4 + sum(m1[0]['icnt'][start:end])*2/1e6 + sum(m3[0]['icnt'][start:end])*2/1e6  + sum(m4[0]['icnt'][start:end])*2/1e6

total_delay = m0[0]['delay']/1e6*4 + m1[0]['delay']/1e6 + m3[0]['delay']/1e6 + m4[0]['delay']/1e6

print(latency)
print('check:',total_delay-sum(latency))
