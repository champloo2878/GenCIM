# from sw_decima import Bert_decision
import hw_config as cfg
import numpy as np
import pickle as pk
from evaluator import evaluate
import sw_decima as sd

bus_width = 256
is_depth = 32
al = 64
pc = 32
scr = 32
os_depth = 2048

op_target = 'ee_L2'

acc0 = cfg.hwc(config = cfg.Config(bus_width = bus_width, is_depth = is_depth, al = al, pc = pc, scr = scr, os_depth = os_depth))

# return_metric, decision, total_area = Bert_decision(acc0, seq_len=64, hidden_size=1024, head_num=12, num_layers=12, op_target=op_target)


# print(return_metric)
# print(decision)
# print(total_area)

# gli = ('proj',(128,64,128))
# gli = ('a2a', (16, 1024, 16))

def space_detect(filename):
    with open(filename,"rb") as f:
        dse_res_a = pk.load(f)
        

    bw = dse_res_a[0][3][0]
    ih = dse_res_a[0][3][1]
    al = dse_res_a[0][3][2]
    pc = dse_res_a[0][3][3]
    sc = dse_res_a[0][3][4]
    oh = dse_res_a[0][3][5]
    spaces = [[bw],[ih],[al],[pc],[sc],[oh]]

    for i in range(len(dse_res_a)):
        for j in range(6):
            same_fg = 0
            for k in range(len(spaces[j])):
                if spaces[j][k] == dse_res_a[i][3][j]:
                    same_fg = 1
            if same_fg == 0:
                spaces[j].append(dse_res_a[i][3][j])
    name = ['buswidth','is_depth','al','pc','scr','os_depth']
    for i in range(len(name)):
        print(name[i]+"_space:",spaces[i])

    return spaces


op_target = 'ee_L2'

space_detect("./dse_pks/bert_large_N512_dse_0415_"+op_target+".pk")

print('\n')
space_detect("./dse_pks/bert_large_N128_dse_0415_"+op_target+".pk")


