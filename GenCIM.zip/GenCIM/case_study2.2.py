import pickle as pk
import numpy as np
import matplotlib.pyplot as plt
import hw_config as cfg
from sw_decima import Encoder_decision

# hybrid seq_len
def space_detect(filename):
    with open(filename,"rb") as f:
        dse_res_a = pk.load(f)

    bw = dse_res_a[0][3][0]
    ih = dse_res_a[0][3][1]
    al = dse_res_a[0][3][2]
    pc = dse_res_a[0][3][3]
    sc = dse_res_a[0][3][4]
    oh = dse_res_a[0][3][5]
    spaces = [[bw],[ih],[al],[pc],[sc],[oh]]

    for i in range(len(dse_res_a)):
        for j in range(6):
            same_fg = 0
            for k in range(len(spaces[j])):
                if spaces[j][k] == dse_res_a[i][3][j]:
                    same_fg = 1
            if same_fg == 0:
                spaces[j].append(dse_res_a[i][3][j])
    name = ['buswidth','is_depth','al','pc','scr','os_depth']
    for i in range(len(name)):
        print(name[i]+"_space:",spaces[i])

    return spaces
def cut_for_plot(filename):
    with open(filename + ".pk","rb") as f:
        dse_res = pk.load(f)
    
    cut_res = np.zeros((len(dse_res),2))
    for i in range(len(dse_res)):
        cut_res[i][0] = dse_res[i][0]
        cut_res[i][1] = dse_res[i][1]
    
    with open(filename + "_cut.pk","wb") as f:
        pk.dump(cut_res, f)
    print("before:", len(dse_res))
    print("after:", len(cut_res))

cut = 0 

name = 'bert_large'
# name = 'gpt2_xl'
op_target = 'throughput'
# op_target = 'ee_L2'

seq_len0 = 128
seq_len1 = 512
color = ['coral','yellow','springgreen','royalblue', 'deeppink','red']

filename = "./dse_pks/"+name+"_N"+str(seq_len0)+"_dse_0415_"

spaces = space_detect(filename + "throughput"+".pk")

buswidth_space = spaces[0]
scr_space = spaces[4]


# if cut:
    # cut_for_plot("./dse_pks/"+name+"_N"+str(seq_len)+"_dse_ee_L2")
    # cut_for_plot("./dse_pks/"+name+"_N"+str(seq_len)+"_dse_throughput")

with open(filename + op_target + "_cut.pk","rb") as f:
    dse_res0 = pk.load(f)

with open(filename + op_target + "_cut.pk","rb") as f:
    dse_res1 = pk.load(f)

op0 = 78920024064
op1 = 335007449088

# combine:
s0 = 1
s1 = 1
dse_res = np.zeros((len(dse_res0),2))
print(dse_res0[:,0] - dse_res1[:,0])
dse_res[:,0] = dse_res0[:,0]
dse_res[:,1] = (s0*op0 + s1*op1)/(s0*op0/dse_res0[:,1] + s1*op1/dse_res1[:,1])



# area eff
if op_target == 'throughput':
    for i in range(len(dse_res)):
        #dse_res[i][1] = dse_res[i][1]/dse_res[i][0]*1e6
        pass

dse_res_for_opt_constrain = np.zeros((len(dse_res),2))
for i in range(len(dse_res)):
    dse_res_for_opt_constrain[i,0] = dse_res[i,0]
    if dse_res[i,0] >= 5*1e6:
        dse_res_for_opt_constrain[i,1] = 0
    else:
        dse_res_for_opt_constrain[i,1] = dse_res[i,1]

max_point = np.argmax(dse_res_for_opt_constrain[:,1])




lum = 'buswidth' if op_target == 'throughput' else 'scr'
lum_index = 0 if op_target == 'throughput' else 4
lum_space = buswidth_space if op_target == 'throughput' else scr_space

partial_point = [[] for i in range(len(lum_space))]

with open(filename+op_target+".pk","rb") as f:
    dse_res_a0 = pk.load(f)
with open(filename+op_target+".pk","rb") as f:
    dse_res_a1 = pk.load(f)

for i in range(len(dse_res_a0)):
    for cpi in range(len(lum_space)):
        if dse_res_a0[i][3][lum_index] == lum_space[cpi]:
            partial_point[cpi].append([dse_res[i][0], dse_res[i][1]])

partial_point_list = []
for i in range(len(lum_space)):
    partial_point_list.append(np.array(partial_point[i]))
print('check:',len(dse_res_a0))

for i in range(len(lum_space)):
    plt.scatter(partial_point_list[i][:,0],partial_point_list[i][:,1],color=color[i],label=lum+str(lum_space[i]),marker='o',edgecolors='black')
plt.scatter(dse_res[max_point,0],dse_res[max_point,1],marker='*',s=150,color='#FF0065')

plt.legend()
plt.show()

print('opt_point0:',dse_res_a0[max_point])
print('opt_point1:',dse_res_a1[max_point])

print('opt_point:',dse_res[max_point])


acc0 = cfg.hwc(config = cfg.Config(
                            bus_width = dse_res_a0[max_point][3][0],
                            is_depth = dse_res_a0[max_point][3][1], 
                            al = dse_res_a0[max_point][3][2], 
                            pc = dse_res_a0[max_point][3][3], 
                            scr = dse_res_a0[max_point][3][4], 
                            os_depth = dse_res_a0[max_point][3][5]
                        )
                    )

if name == 'bert_large':
    Encoder_decision(acc0, seq_len=seq_len0, hidden_size=1024, head_num=16, num_layers=24, op_target=op_target, check=1)
    Encoder_decision(acc0, seq_len=seq_len1, hidden_size=1024, head_num=16, num_layers=24, op_target=op_target, check=1)


