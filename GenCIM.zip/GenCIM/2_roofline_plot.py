import pickle as pk
import numpy as np
import matplotlib.pyplot as plt
import hw_config as cfg

colors = ['red','darkgreen','lime','cyan','dodgerblue','blue','fuchsia','pink','w']

#0.3, 
#1.503, 
#0.3
#2.113,
gli_ad = [0.3, 0.1227, 0.718, 1.0103,  2.575, 2.834, 1.496, 2.07, 3.21]

#"gpt-xl.ffn1(1)", #
#"bert-base.ffn1(16)", #
#"gpt-base.ffn1(1)",
#"vit-base.mha(197)",

gli_name = [
    "gpt-xl.ffn1(1)",
    "gpt-xl.mha(1)", 
    "bert-base.mha(4)",
    "bert-base.mha(8)",
    "vit-large.ffn1(197)",
    "bert-large.ffn2(512)",
    "bert-base.ffn2(16)",
    "bert-base.ffn2(64)",
    "bert-large.ffn1(1024)"
    ]


def get_max_throughput(i_gli):
    filename = "./2_dse_pks/" + gli_name[i_gli] + ".pk" 
    with open(filename,'rb') as f:
        dse_res = pk.load(f)

    throughputs = np.zeros(len(dse_res))
    for i in range(len(dse_res)):
        throughputs[i] = dse_res[i][1]/dse_res[i][2]
    max_throughput_index = np.argmax(throughputs)
    return throughputs[max_throughput_index]
    print(throughputs[max_throughput_index])
    print(dse_res[max_throughput_index])

def get_throughputs(i_gli):
    filename = "./2_dse_pks/" + gli_name[i_gli] + ".pk" 
    with open(filename,'rb') as f:
        dse_res = pk.load(f)

    throughputs = np.zeros(len(dse_res))
    for i in range(len(dse_res)):
        throughputs[i] = dse_res[i][1]/dse_res[i][2]

    return throughputs #, dse_res

cc = 'grey'

# plot every 100 point
for i_gli in range(len(gli_ad)):
    print(i_gli)
    throughput = get_throughputs(i_gli)

    for j in range(len(throughput)):
        if j%100 == 0:
            plt.scatter(gli_ad[i_gli], np.log10(throughput[j]),c=colors[i_gli])
            # plt.scatter(gli_ad[i_gli], np.log10(throughput[j]),c='silver')
            pass

# plot the max point
max_ths = np.zeros(len(gli_ad))
for i_gli in range(len(gli_ad)):
    max_ths[i_gli] = get_max_throughput(i_gli)
    plt.scatter(gli_ad[i_gli],np.log10(max_ths[i_gli]),c=colors[i_gli])
    # plt.scatter(gli_ad[i_gli],np.log10(max_ths[i_gli]),c='grey')

print(max_ths)

plt.show()
