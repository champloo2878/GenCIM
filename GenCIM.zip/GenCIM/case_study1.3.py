from evaluator import evaluate
import hw_config as cfg
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import host_subplot
from mpl_toolkits import axisartist


acc0 = cfg.hwc(config = cfg.Config(bus_width = 256, is_depth = 1024, al = 128, pc = 8, scr = 16, os_depth = 1024))

# seq_len = [1, 64, 128, 256, 512, 1024]
seq_len = [16, 128, 1024]
bit_energy_L2 = [0.5,1,1.5,2,2.5]

cmpme = np.zeros((len(bit_energy_L2),8,6))

dataflow_num = [0,1,2,3]
# dataflow_num = [0,1,2,3,4,5,6,7]

plot_energy = 1  # plot energy or latency

for si in range(len(bit_energy_L2)):

    gli = ('proj', (128,3072,768))

    dataflow = ['isap','ispp','wsap','wspp','r_isap','r_ispp','r_wsap','r_wspp']
    color = ['tomato','orange','sienna','forestgreen','darkcyan','royalblue','darkviolet','deeppink']
    metric_rec = [0 for i in range(8)]

    metric_rec[0] = evaluate(acc0, gli, 'isap', bit_energy_L2=bit_energy_L2[si])
    metric_rec[1] = evaluate(acc0, gli, 'ispp', bit_energy_L2=bit_energy_L2[si])
    metric_rec[2] = evaluate(acc0, gli, 'wsap', bit_energy_L2=bit_energy_L2[si])
    metric_rec[3] = evaluate(acc0, gli, 'wspp', bit_energy_L2=bit_energy_L2[si])

    rv_gli = (gli[0],(gli[1][2],gli[1][1],gli[1][0]))

    metric_rec[4] = evaluate(acc0, rv_gli, 'isap', bit_energy_L2=bit_energy_L2[si])
    metric_rec[5] = evaluate(acc0, rv_gli, 'ispp', bit_energy_L2=bit_energy_L2[si])
    metric_rec[6] = evaluate(acc0, rv_gli, 'wsap', bit_energy_L2=bit_energy_L2[si])
    metric_rec[7] = evaluate(acc0, rv_gli, 'wspp', bit_energy_L2=bit_energy_L2[si])

    for i in dataflow_num:
        if plot_energy:
            cmpme[si,i,0] = metric_rec[i]['energy'][18,0] #fd_is
            cmpme[si,i,1] = metric_rec[i]['energy'][18,2] #cm_macros
            cmpme[si,i,2] = metric_rec[i]['energy'][18,4] #gd_os
            cmpme[si,i,3] = metric_rec[i]['energy'][18,1] +  metric_rec[i]['energy'][18,3] + metric_rec[i]['energy'][18,5] + metric_rec[i]['energy'][18,6] #regs

            cmpme[si,i,4] = metric_rec[i]['energy_on_L2'] #L2
            cmpme[si,i,5] = metric_rec[i]['energy_L2']

            print('check:', metric_rec[i]['energy'][18,7] - cmpme[si,i,0] - cmpme[si,i,1] - cmpme[si,i,2] - cmpme[si,i,3])


        else:
            pass

    print(bit_energy_L2[si])


x_plot = [i for i in range(len(bit_energy_L2))]
for i in dataflow_num:
    plt.scatter(x_plot, cmpme[:,i,5], label=dataflow[i], color=color[i])
    plt.plot(x_plot, cmpme[:,i,5], linestyle = '--', color = color[i])
    print(dataflow[i],cmpme[:,i,5])


plt.xticks(x_plot,labels = bit_energy_L2)
plt.legend()

plt.show()









