import matplotlib.pyplot as plt

# Data for the pie chart
#data = [2.05023051e+07, 8.76397604e+08, 1.52531929e+07, 1.22520569e+08, 4.38881894e+09]
labels = ['IS', 'CIM', 'OS', 'Regs', 'L2']

# data = [7.680000e-04, 2.293760e-01, 1.228800e-02, 1.888256e+00]
data = [0.012288, 0.917504, 0.012288, 3.597056]

#data = [3.91917384e+07, 1.03412664e+09, 1.66459625e+08, 1.23065108e+08, 5.60922624e+08]

labels = ['Lin','Lwt','Cmpfis','Cmpfgt']

# Plotting the pie chart
plt.figure(figsize=(7, 7))
plt.pie(data, labels=labels, autopct='%1.1f%%', startangle=90)
#plt.pie(data, labels=labels, startangle=90)
# plt.title('Pie Chart Representation')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

# Show the plot
plt.show()
