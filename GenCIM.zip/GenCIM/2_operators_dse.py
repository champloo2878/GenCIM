from sw_decima import block_decision, Encoder_decision, Decoder_decision_w_kvcache, operator_decision
import hw_config as cfg
import numpy as np
import pickle as pk
import time


gli_name_0 = [
    "gpt-xl.ffn1(1)",
    "gpt-xl.mha(1)", 
    "bert-base.mha(4)",
    "bert-base.mha(8)",
    "bert-base.ffn1(16)",
    "vit-base.mha(197)",
    "vit-large.ffn1(197)",
    "bert-large.ffn2(512)"
    ]
gli_ad_0 = [0.3, 0.1227, 0.718, 1.0103, 1.503, 2.113, 2.575, 2.834]
glis_0 = [
    ('proj',(1,1600,5400)),   # gpt-xl.ffn1(1)          0.3
    ('a2a',(1,1600,25)),      # gpt-xl.mha(1)           0.1227
    ('a2a',(4, 768, 12)),     # bert-base.mha(4)        0.718
    ('a2a',(8, 768, 12)),     # bert-base.mha(8)        1.0103
    ('proj',(16, 768, 3072)), # bert-base.ffn1(16)      1.503
    ('a2a',(197, 768, 12)),    # vit-base.mha(197)      2.113
    ('proj',(197, 1024, 4096)),# vit-large.ffn1(197)    2.575
    ('proj',(512, 4096, 1024)) # bert-large.ffn2(512)   2.834   
    ]

gli_name = [
    "gpt-base.ffn1(1)",
    "bert-base.ffn2(16)",
    "bert-base.ffn2(64)",
    "bert-large.ffn1(1024)"
]
gli_ad = [0.3, 1.496, 2.07, 3.21]
glis = [
    ('proj',(1,768,3072)),
    ('proj',(16,3072,768)),
    ('proj',(64,3072,768)),
    ('proj',(1024,1024,4096))
]

# full space
# bus_width_space = [128, 256, 512, 1024, 2048, 4096]
# is_depth_space = [64, 512, 1024]
# al_space = [64, 128, 256, 512]
# pc_space = [8, 16, 32, 64]
# scr_space = [4, 8, 16, 32, 64]
# os_depth_space = [128, 1024, 4096]

# simple test space
# bus_width_space = [128, 256, 512]
# is_depth_space = [64]
# al_space = [64]
# pc_space = [8]
# scr_space = [4]
# os_depth_space = [128]

# accelerate space
bus_width_space = [128, 256, 1024, 2048, 4096]
is_depth_space = [64, 512, 1024]
al_space = [64, 256, 512]
pc_space = [8, 16, 64]
scr_space = [4, 8, 32, 64]
os_depth_space = [128, 1024, 4096]

# num_point print
num_point = len(bus_width_space)*len(is_depth_space)*len(al_space)*len(pc_space)*len(scr_space)*len(os_depth_space)
print(num_point)


for i_gli in range(len(gli_name)):
    dse_res = []
    ir=0

    filename = "./2_dse_pks/" + gli_name[i_gli] + ".pk" 

    for al in al_space:
        for is_depth in is_depth_space:
            for bus_width in bus_width_space:
                if bus_width > al *8:
                    continue
                else:
                    for pc in pc_space:
                        for scr in scr_space:
                            for os_depth in os_depth_space:
    # bus_width = bus_width_space[2]
    # is_depth = is_depth_space[2]
    # al = al_space[2]
    # pc = pc_space[2]
    # scr = scr_space[2]
    # os_depth = os_depth_space[2]

                                acc0 = cfg.hwc(config = cfg.Config(bus_width = bus_width, is_depth = is_depth, al = al, pc = pc, scr = scr, os_depth = os_depth))

                                dse_res.append(operator_decision(acc0, glis[i_gli], 'throughput'))
                                # dse_res.append([m[0]['energy_L2'], m[0]['op'], m[0]['delay'], m[0]['area'][7], m[1], bus_width, is_depth, al, pc, scr, os_depth])
                                ir=ir+1
                                print(gli_name[i_gli],'---',num_point,'---',ir)

    with open(filename,"wb") as f:
        pk.dump(dse_res, f)

    print(dse_res)
