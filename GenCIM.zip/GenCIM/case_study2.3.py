import pickle as pk
import numpy as np
import matplotlib.pyplot as plt


def cut_for_plot(filename):
    with open(filename + ".pk","rb") as f:
        dse_res = pk.load(f)
    
    cut_res = np.zeros((len(dse_res),2))
    for i in range(len(dse_res)):
        cut_res[i][0] = dse_res[i][0]
        cut_res[i][1] = dse_res[i][1]
    
    with open(filename + "_cut.pk","wb") as f:
        pk.dump(cut_res, f)
    
    print("tail cutted")

cut = 0 
op_target = 'EDP'
seq_len = 512
#color = ['tomato','orange','sienna','forestgreen','darkcyan','royalblue','darkviolet','deeppink']
color = ['coral','yellow','springgreen','royalblue', 'deeppink','red']


if cut:
    cut_for_plot("./dse_pks/bert_large_N"+str(seq_len)+"_dse_EDP")
    cut_for_plot("./dse_pks/bert_large_N"+str(seq_len)+"_dse_ee_L2")
    cut_for_plot("./dse_pks/bert_large_N"+str(seq_len)+"_dse_throughput")


with open("./dse_pks/bert_large_N"+str(seq_len)+"_dse_"+op_target+"_cut.pk","rb") as f:
    dse_res = pk.load(f)

with open("./dse_pks/bert_large_N"+str(seq_len)+"_dse_"+op_target+".pk","rb") as f:
    dse_res_a = pk.load(f)



max_point = np.argmin(dse_res[:,1])


plt.scatter(dse_res[:,0],dse_res[:,1],marker='o',edgecolors='black')

plt.scatter(dse_res[max_point,0],dse_res[max_point,1],marker='*',s=150,color='#FF0065')

plt.legend()
plt.show()

print('opt_point:',dse_res_a[max_point])
