from evaluator import evaluate
import hw_config as cfg
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import host_subplot
from mpl_toolkits import axisartist



color = ['tomato','orange','sienna','forestgreen','darkcyan','royalblue','darkviolet','deeppink']
c = ['#F8E620', '#91D542', '#35B777', '#1F928B', '#30688D', '#413E85']
# acc0 = cfg.hwc(config = cfg.Config(bus_width = 256, is_depth = 1024, al = 128, pc = 16, scr = 64, os_depth = 2048))
acc0 = cfg.hwc(config = cfg.Config(bus_width = 256, is_depth = 1024, al = 128, pc = 32, scr = 32, os_depth = 1024))
# seq_len = [1, 64, 128, 256, 512, 1024]
seq_len = [1024, 1024, 128]
acc_l = 3027
input_c = 768

cmpme = np.zeros((len(seq_len),8,6))

# dataflow_num = [0,1,2,3]
dataflow_num = [0,1,2,3,4,5,6,7]

# tm = 1
plot_energy = 0 # plot energy or latency

for si in range(len(seq_len)):

    gli = ('proj', (seq_len[si],acc_l,input_c))

    dataflow = ['isap','ispp','wsap','wspp','r_isap','r_ispp','r_wsap','r_wspp']
    metric_rec = [0 for i in range(8)]

    metric_rec[0] = evaluate(acc0, gli, 'isap')
    metric_rec[1] = evaluate(acc0, gli, 'ispp')
    metric_rec[2] = evaluate(acc0, gli, 'wsap')
    metric_rec[3] = evaluate(acc0, gli, 'wspp')

    rv_gli = (gli[0],(gli[1][2],gli[1][1],gli[1][0]))

    metric_rec[4] = evaluate(acc0, rv_gli, 'isap')
    metric_rec[5] = evaluate(acc0, rv_gli, 'ispp')
    metric_rec[6] = evaluate(acc0, rv_gli, 'wsap')
    metric_rec[7] = evaluate(acc0, rv_gli, 'wspp')

    for i in dataflow_num:
        if plot_energy:
            cmpme[si,i,0] = metric_rec[i]['energy'][18,0] #fd_is
            cmpme[si,i,1] = metric_rec[i]['energy'][18,2] #cm_macros
            cmpme[si,i,2] = metric_rec[i]['energy'][18,4] #gd_os
            cmpme[si,i,3] = metric_rec[i]['energy'][18,1] +  metric_rec[i]['energy'][18,3] + metric_rec[i]['energy'][18,5] + metric_rec[i]['energy'][18,6] #regs

            cmpme[si,i,4] = metric_rec[i]['energy_on_L2'] #L2

            print('check:', metric_rec[i]['energy'][18,7] - cmpme[si,i,0] - cmpme[si,i,1] - cmpme[si,i,2] - cmpme[si,i,3])


        else:
            cmpme[si,i,0] = sum(metric_rec[i]['icnt'][0:2])*2/1e6
            cmpme[si,i,1] = sum(metric_rec[i]['icnt'][2:4])*2/1e6
            cmpme[si,i,2] = sum(metric_rec[i]['icnt'][4:9])*2/1e6
            cmpme[si,i,3] = sum(metric_rec[i]['icnt'][9:15])*2/1e6
            cmpme[si,i,4] = metric_rec[i]['icnt'][15]*2/1e6
            cmpme[si,i,5] = metric_rec[i]['icnt'][16]*2/1e6
            print('check:', sum(cmpme[si,i,0:6])-metric_rec[i]['delay']/1e6)


    print(seq_len[si])

    # w=0.8
    # plt.bar(dataflow, cmpme[si,:,3]+cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], width=w, color='#FDB32E')
    # plt.bar(dataflow, cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], width=w, color='#EC7853')
    # plt.bar(dataflow, cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], width=w, color='#CC4975')
    # plt.bar(dataflow, cmpme[si,:,0]+cmpme[si,:,4], width=w, color='#9E189D')
    # plt.bar(dataflow, cmpme[si,:,4], width=w, color='#16068A')

    if plot_energy:
        plt.subplot(1,3,si+1)
        plt.barh(dataflow, width=cmpme[si,:,3]+cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], color=c[1])
        plt.barh(dataflow, width=cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], color=c[2])
        plt.barh(dataflow, width=cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4], color=c[3])
        plt.barh(dataflow, width=cmpme[si,:,0]+cmpme[si,:,4], color=c[4])
        plt.barh(dataflow, width=cmpme[si,:,4], color=c[5])

    else:
        plt.subplot(1,3,si+1)
        plt.barh(dataflow, width=cmpme[si,:,3]+cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,4]+cmpme[si,:,5], color=c[0])
        plt.barh(dataflow, width=cmpme[si,:,2]+cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,3]+cmpme[si,:,4], color=c[1])
        plt.barh(dataflow, width=cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,2]+cmpme[si,:,3], color=c[2])
        plt.barh(dataflow, width=cmpme[si,:,1]+cmpme[si,:,0]+cmpme[si,:,2], color=c[3])
        plt.barh(dataflow, width=cmpme[si,:,0]+cmpme[si,:,1], color=c[4])
        plt.barh(dataflow, width=cmpme[si,:,0], color=c[5])



# x_plot = [i for i in range(len(seq_len))]
# for i in dataflow_num:
#     plt.scatter(x_plot, cmpme[:,i,tm], label=dataflow[i], color=color[i])
#     plt.plot(x_plot, cmpme[:,i,tm], linestyle = '--', color = color[i])
#     print(dataflow[i],cmpme[:,i,tm])


# plt.xticks(x_plot,labels = seq_len)
# plt.legend()

plt.show()








