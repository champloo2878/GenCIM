import pickle as pk
import numpy as np
import matplotlib.pyplot as plt
import hw_config as cfg
from sw_decima import Encoder_decision, Decoder_decision_w_kvcache


def space_detect(filename):
    with open(filename,"rb") as f:
        dse_res_a = pk.load(f)

    bw = dse_res_a[0][3][0]
    ih = dse_res_a[0][3][1]
    al = dse_res_a[0][3][2]
    pc = dse_res_a[0][3][3]
    sc = dse_res_a[0][3][4]
    oh = dse_res_a[0][3][5]
    spaces = [[bw],[ih],[al],[pc],[sc],[oh]]

    for i in range(len(dse_res_a)):
        for j in range(6):
            same_fg = 0
            for k in range(len(spaces[j])):
                if spaces[j][k] == dse_res_a[i][3][j]:
                    same_fg = 1
            if same_fg == 0:
                spaces[j].append(dse_res_a[i][3][j])
    name = ['buswidth','is_depth','al','pc','scr','os_depth']
    for i in range(len(name)):
        print(name[i]+"_space:",spaces[i])

    return spaces
def cut_for_plot(filename):
    with open(filename + ".pk","rb") as f:
        dse_res = pk.load(f)
    
    cut_res = np.zeros((len(dse_res),2))
    for i in range(len(dse_res)):
        cut_res[i][0] = dse_res[i][0]
        cut_res[i][1] = dse_res[i][1]
    
    with open(filename + "_cut.pk","wb") as f:
        pk.dump(cut_res, f)
    print("before:", len(dse_res))
    print("after:", len(cut_res))

cut = 1

# name = 'vit_huge'
name = 'bert_large'
# name = 'gpt2_xl'

op_target = 'throughput'
# op_target = 'ee_L2'

seq_len = 512

filename = "./dse_pks/"+name+"_N"+str(seq_len)+"_dse_0415_"

# color = ['blue','orange','springgreen','yellow', 'violet','#0000FF', 'deeppink', 'black']
color = ['#F8E620','#91D542','#35B777','#1F928B','#30688D','#413E85']
spaces = space_detect(filename + op_target +".pk")
buswidth_space = spaces[0]
scr_space = spaces[4]

if cut:
    cut_for_plot(filename+op_target)

with open(filename+op_target+"_cut.pk","rb") as f:
    dse_res = pk.load(f)


# area eff
if op_target == 'throughput':
    for i in range(len(dse_res)):
        # dse_res[i][1] = dse_res[i][1]/dse_res[i][0]*1e6
        pass

with open(filename+op_target+".pk","rb") as f:
    dse_res_a = pk.load(f)

print(dse_res)
dse_res_w_const = np.zeros((len(dse_res),2))
print(dse_res_w_const)
for i in range(len(dse_res)):
    dse_res_w_const[i] = dse_res[i]
    if dse_res[i][0] > 7e6:
        dse_res_w_const[i][1] = 0

print(np.max(dse_res_w_const[:,1]))
print(np.argmax(dse_res_w_const[:,1]))

maxid = np.argmax(dse_res_w_const[:,1])
print(dse_res_a[maxid])


acc0 = cfg.hwc(config = cfg.Config(
                            bus_width = dse_res_a[maxid][3][0],
                            is_depth = dse_res_a[maxid][3][1], 
                            al = dse_res_a[maxid][3][2], 
                            pc = dse_res_a[maxid][3][3], 
                            scr = dse_res_a[maxid][3][4], 
                            os_depth = dse_res_a[maxid][3][5]
                        )
                    )

if name == 'bert_large':
    Encoder_decision(acc0, seq_len=seq_len, hidden_size=1024, head_num=16, num_layers=24, op_target=op_target, check=1)


print(dse_res_a[3000][2][-1])



lum_index = 4

lum_space = spaces[lum_index]

# lum_space = ['isap','ispp','wsap','wspp','r_isap','r_ispp','r_wsap','r_wspp']

partial_point = [[] for i in range(len(lum_space))]

for i in range(len(dse_res_a)):
    for cpi in range(len(lum_space)):
        #if dse_res_a[i][2][-1] == lum_space[cpi]:
        if dse_res_a[i][3][lum_index] == lum_space[cpi]:
            partial_point[cpi].append([dse_res[i][0], dse_res[i][1]])
partial_point_list = []
for i in range(len(lum_space)):
    partial_point_list.append(np.array(partial_point[i]))

for i in range(len(lum_space)):
    print(partial_point_list[i])
    if len(partial_point_list[i]) != 0:
        alpha = 1 # if i== 3 else 1
        plt.scatter(partial_point_list[i][:,0],partial_point_list[i][:,1],color=color[i],label=lum_space[i],marker='o',edgecolors='black',s=65,alpha=alpha)
    pass

plt.xlim([0,7.3e6])
# plt.ylim([0,7.4e3])
plt.legend()
plt.show()




