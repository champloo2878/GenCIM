from sw_decima import Encoder_decision, Decoder_decision_w_kvcache
import hw_config as cfg
import numpy as np
import pickle as pk
import time


bus_width_space = [128, 256, 512]

is_depth_space = [64]
al_space = [64, 128, 256, 512]
pc_space = [8]

scr_space = [4, 64]

os_depth_space = [128]

# bus_width_space = [128, 256, 512, 1024, 2048, 4096]
# is_depth_space = [128, 256, 512, 1024]
# al_space = [64, 128, 256, 512]
# pc_space = [8, 16, 32]
# scr_space = [8, 16, 32, 64]
# os_depth_space = [256, 1024, 2048]

# bus_width_space = [1024]
# is_depth_space = [256]
# al_space = [128]
# pc_space = [8]
# scr_space = [16, 32]
# os_depth_space = [256]


# NN paras:
name = 'gpt2_xl'
seq_len = 128
hidden_size = 1600
head_num = 25
num_layers = 48

start = time.time()
with open(name+"_N"+str(seq_len)+".log","w") as dlog:    
    dlog.write('dse_start!\n')


for op_target in ['throughput']: 
    pi = 0
    dse_res = []
    for al in al_space:
        for is_depth in is_depth_space:
            for bus_width in bus_width_space:
                if bus_width > al *8:
                    continue
                else:
                    for pc in [8]:
                        for scr in scr_space:
                            for os_depth in os_depth_space:

                                acc0 = cfg.hwc(config = cfg.Config(bus_width = bus_width, is_depth = is_depth, al = al, pc = pc, scr = scr, os_depth = os_depth))

                                return_metric, total_area = Decoder_decision_w_kvcache(
                                                                                acc0, 
                                                                                seq_len = seq_len, 
                                                                                hidden_size = hidden_size, 
                                                                                head_num = head_num, 
                                                                                num_layers = num_layers, 
                                                                                op_target = op_target
                                                                            )

                                dse_res.append([total_area, return_metric, 0, [bus_width, is_depth, al, pc, scr, os_depth]])

                                pi += 1
                                print(op_target+".point:", pi)

    print(dse_res)

    with open("./dse_pks/"+name+"_N"+str(seq_len)+"_dse_"+op_target+".pk", "wb") as f:
        pk.dump(dse_res, f)

    with open(name+"_N"+str(seq_len)+".log","a") as dlog:    
        dlog.write(str(time.time()-start)+'\n')
# FOR DATAFLOW DISSCUSION, BERT_decision -> BLOCK_decision
