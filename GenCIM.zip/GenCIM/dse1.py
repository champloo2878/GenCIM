from sw_decima import Encoder_decision, Decoder_decision_w_kvcache
import hw_config as cfg
import numpy as np
import pickle as pk
import time


bus_width_space = [128, 256, 512, 1024, 2048, 4096]
is_depth_space = [64, 512, 1024]
al_space = [64, 128, 256, 512]
pc_space = [8, 16, 32, 64]
scr_space = [4, 8, 16, 32, 64]
os_depth_space = [128, 1024, 4096]


# bus_width_space = [512, 1024, 4096, 8192]
# is_depth_space = [64, 1024]
# al_space = [64, 128, 256, 1024]
# pc_space = [32, 64, 128]
# scr_space = [16, 64]
# os_depth_space = [128, 4096]

# strong experiment
# bus_width_space = [128, 4096, 8192]
# is_depth_space = [4, 256, 16384]
# al_space = [64, 256, 1024]
# pc_space = [8, 64, 256]
# scr_space = [4, 64, 256]
# os_depth_space = [16, 256, 8192]


num_point = len(bus_width_space)*len(is_depth_space)*len(al_space)*len(pc_space)*len(scr_space)*len(os_depth_space)
print(num_point)


# bus_width_space = [1024]
# is_depth_space = [256]
# al_space = [128]
# pc_space = [8]
# scr_space = [32]
# os_depth_space = [256]


# NN paras:
# name = 'bert_large'
name = 'vit_huge'
seq_len = 197
hidden_size = 1280
head_num = 16
num_layers = 32

# filename = "./dse_pks/"+name+"_N"+str(seq_len)+"_dse_strong_"
filename = "./dse_pks/"+name+"_N"+str(seq_len)+"_dse_0415_"

start = time.time()
with open(name+"_N"+str(seq_len)+".log","w") as dlog:    
    dlog.write('dse_start!\n')

for op_target in ['ee_L2','throughput']: 
    pi = 0
    dse_res = []
    for al in al_space:
        for is_depth in is_depth_space:
            for bus_width in bus_width_space:
                if bus_width > al *8:
                    continue
                else:
                    for pc in pc_space:
                        for scr in scr_space:
                            for os_depth in os_depth_space:

                                acc0 = cfg.hwc(config = cfg.Config(bus_width = bus_width, is_depth = is_depth, al = al, pc = pc, scr = scr, os_depth = os_depth))

                                return_metric, decision, total_area = Encoder_decision(
                                                                                acc0, 
                                                                                seq_len = seq_len, 
                                                                                hidden_size = hidden_size, 
                                                                                head_num = head_num, 
                                                                                num_layers = num_layers, 
                                                                                op_target = op_target
                                                                            )

                                    
                                dse_res.append([total_area, return_metric, decision, [bus_width, is_depth, al, pc, scr, os_depth]])
                                

                                pi += 1
                                print(op_target+".point:", pi)


    with open(filename + op_target + ".pk", "wb") as f:
        pk.dump(dse_res, f)

    with open(name+"_N"+str(seq_len)+".log","a") as dlog:    
        dlog.write(str(time.time()-start)+'\n')

# FOR DATAFLOW DISSCUSION, BERT_decision -> BLOCK_decision

